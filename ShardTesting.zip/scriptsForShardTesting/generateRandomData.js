const axios = require('axios');
const fs = require('fs');
const path = require('path');

const alphabets = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N",
    "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];

let measurementsFromFile = fs.readFileSync(path.join(__dirname, '/measurements.json'));
let { measurements } = JSON.parse(measurementsFromFile);
console.log(measurements);

const randomData = (measurement) => {
    return `${measurement}_${alphabets[Math.floor(Math.random() * 26)]}`;
}

const chunkedData = (measurement) => {
    const createdData = [];
    for (let i = 0; i < Math.floor(Math.random() * 10)+2; i++) {
        createdData.push({ tag: 'test', value: randomData(measurement) });
    }
    return createdData;
};


setInterval(async () => {
    let baseTime = new Date().getTime();
    for (let j = 0; j < measurements.length; j++) {
        const reqObject = {
            device: measurements[j],
            time: baseTime + Math.floor(Math.random() * 100) + 1,
            data: chunkedData(measurements[j])
        }
        console.log({ reqObject });
        try {
            await axios.post('http://localhost:4001/', reqObject);
            // else
            // await axios.post('http://localhost:4001/writeSSData', reqObject);

        } catch (error) {
            console.log({ error });
        }
    }
}, 1000); 


// shard 4
// name: database
// tags: database=prod
// numMeasurements numSeries
// --------------- ---------
// 58              58

// name: database
// tags: database=backup
// numMeasurements numSeries
// --------------- ---------
// 261             262




// shard 1


// name: database
// tags: database=backup
// numMeasurements numSeries
// --------------- ---------
// 273             274

// name: database
// tags: database=prod
// numMeasurements numSeries
// --------------- ---------
// 70              70






// shard 2
// name: database
// tags: database=prod
// numMeasurements numSeries
// --------------- ---------
// 158             158

// name: database
// tags: database=backup
// numMeasurements numSeries
// --------------- ---------
// 241             242




// shard 3

// tags: database=backup
// numMeasurements numSeries
// --------------- ---------
// 240             240

// name: database
// tags: database=prod
// numMeasurements numSeries
// --------------- ---------
// 123             124

