const alphabets = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N",
    "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
const numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

const measurements = [];
const fs = require('fs');
const path = require('path');

fs.truncateSync(path.join(__dirname, '/measurements.json'), 0);
for (let i = 0; i < 300; i++) {
    let measurementName = '';
    for (let j = 0; j < 6; j++)
        measurementName += alphabets[Math.floor(Math.random() * 26)];
    measurementName += '_';
    measurementName += Math.floor(Math.random() * 1000) + 1;
    measurements.push(measurementName);
}
console.log({ measurements });
fs.appendFileSync(path.join(__dirname, '/measurements.json'), JSON.stringify({ measurements }, null, 4));